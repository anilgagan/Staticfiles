from django.shortcuts import render

import datetime

def date_time_view(request):
    date=datetime.datetime.now()
    h=int(date.strftime('%H'))
    if h<12:
        msg='Hello Guest |||Very good morning'
    elif h<16:
        msg='Hello Guest |||Very good afternoo'
    elif h<21:
        msg='Hello Guest |||Very good evening'
    else:
        msg='Hello Guest |||Very good night'
    
    my_dict ={'date':date,'msg':msg}
    return render (request,'testapp/results.html',my_dict)
